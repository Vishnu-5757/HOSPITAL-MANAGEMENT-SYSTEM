from django import forms
from .models import Bill, BillItem

class BillForm(forms.ModelForm):
    class Meta:
        model = Bill
        fields = ['customer', 'bill_number', 'date']

class BillItemFormSet(forms.ModelForm):
    class Meta:
        model = BillItem
        fields = ['item_type', 'amount', 'description']

BillItemFormSet = forms.inlineformset_factory(Bill, BillItem, form=BillItemFormSet, extra=1)