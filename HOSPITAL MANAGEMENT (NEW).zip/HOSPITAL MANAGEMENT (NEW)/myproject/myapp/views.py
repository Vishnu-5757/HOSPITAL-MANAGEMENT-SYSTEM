
from django.shortcuts import render,redirect
from .models import *
from django.db.models import Q
from django.http import HttpResponse,HttpResponseRedirect
from datetime import date,datetime
from django.db.models import Max
from decimal import Decimal
from django.http import JsonResponse
from django.db.models import Avg
from django.template.loader import get_template
from datetime import datetime, timedelta
from django.db.models import Count
from django import forms
from .forms import BillForm, BillItemFormSet

from django.db.models import Sum

def index(request):

    return render(request,'index.html')

def make_bill(request):
    # if request.method == 'POST':
    #     uid = request.session.get("uid")
    #     obj1 = UserRegister.objects.get(uid=uid)

    #     test_fullname = request.POST.get("test_fullname")
    #     test_email = request.POST.get("test_email")
    #     test_phone = request.POST.get("test_phone")
    #     test_choose = request.POST.get("test_choose")
    #     # test_district = request.POST.get("test_district")
    #     test_address = request.POST.get("test_address")

    #     # Create the RegisterTest object
    #     aot = RegisterTest.objects.create(
    #         test_fullname=test_fullname,
    #         test_email=test_email,
    #         test_phone=test_phone,
    #         test_choose=test_choose,
    #         # test_district=test_district,
    #         test_address=test_address,
    #         test_status="pending",
    #         uid=obj1,
    #         # u10="go"
    #     )

    #     # Save the object to get the test_id
    #     aot.save()

    #     # Redirect to the payment page with the test_id in the query string
    #     return HttpResponse('<script>alert("Registered For Test");window.location.href="/user_home"</script>')


    return render(request, 'admin/make_bill.html')




def test(request):
    if request.method == 'POST':
        uid = request.session.get("uid")
        obj1 = UserRegister.objects.get(uid=uid)

        test_fullname = request.POST.get("test_fullname")
        test_email = request.POST.get("test_email")
        test_phone = request.POST.get("test_phone")
        test_choose = request.POST.get("test_choose")
        # test_district = request.POST.get("test_district")
        test_address = request.POST.get("test_address")

        # Create the RegisterTest object
        aot = RegisterTest.objects.create(
            test_fullname=test_fullname,
            test_email=test_email,
            test_phone=test_phone,
            test_choose=test_choose,
            # test_district=test_district,
            test_address=test_address,
            test_status="pending",
            uid=obj1,
            # u10="go"
        )

        # Save the object to get the test_id
        aot.save()

        # Redirect to the payment page with the test_id in the query string
        return HttpResponse('<script>alert("Registered For Test");window.location.href="/user_home"</script>')


    return render(request, 'user/test.html')





def view_tests(request):
    # lab_id=request.session.get("lab_id")

    obj1=RegisterTest.objects.all().exclude(u16="yes")
 
    context={
        'pending':obj1,
     
    }



    return render(request,'admin/view_tests.html',context)




def view_result(request):
    uid=request.session.get("uid")

    obj1=Result.objects.filter(test_id__uid=uid)
    
    # obj2=CollectionStaff.objects.filter(staf_status="approved")
    context={
        'pending':obj1,
       
    }
    


    return render(request,'user/view_result.html',context)

def complatint(request):
    obj2=DoctorRegister.objects.all()
    context={
        'product':obj2
    }

    uid=request.session.get("uid")
    if request.POST:
        uid=request.session.get("uid")
        oto1=UserRegister.objects.get(uid=uid)

        comp_name=request.POST["name"]
        comp_email=request.POST["email"]
        comp_desc=request.POST["message"]
        # image=request.FILES["receipt"]

        aot=ComplaintBox.objects.create(comp_name=comp_name,
                                   comp_email=comp_email,
                                   complaint=comp_desc,
                                #    comp_video=image,
                                   uid=oto1)
        aot.save()
        return HttpResponse('<script>alert("Filed a complaint");window.location.href="/user_home"</script>')
    return render(request,'user/complatint.html',context)



def make_report(request):
    id=request.GET["id"]
    print(id)
    pending=RegisterTest.objects.filter(test_id=id)

    context={
     'pending':pending,
       
    }
    if request.POST:
        id=request.GET["id"]
        obj3=RegisterTest.objects.get(test_id=id)


        patient_fullname=request.POST["sugar_fullname"]
        # sugar_email=request.POST["sugar_date"]
        # patient_district=request.POST["sugar_district"]
        patient_phone=request.POST["sugar_phone"]
        patient_TestType=request.POST["sugar_choose"]
        # sugar_district=request.POST["labtech_address"]
        # sugar_status=request.POST["sugar_status"]
        patient_date=request.POST["patient_date"]
        result_description=request.POST["sugar_description"]
        # result_status=request.POST["result_status"]
        # u22=request.POST["sugar_unit"]
        # u23=request.POST["normal_sugar_level"]
        # u23=request.POST["normal_sugar_level"]
        aot=Result.objects.create(patient_fullname=patient_fullname,
                                              
                                                # patient_district=patient_district,
                                                patient_phone=patient_phone,
                                                patient_TestType=patient_TestType,
                                                # sugar_level=sugar_status,
                                                # sugar_normal=u22,
                                                result_description=result_description,
                                                test_id=obj3,
                                                # result_status=result_status,
                                               
                                                patient_date=patient_date)
        aot.save()
        opp=RegisterTest.objects.filter(test_id=id).update(u16="yes")
        return HttpResponse('<script>alert("Submitted");window.location.href="/view_tests"</script>')



    return render(request,'admin/make_report.html',context)


def add_invoice(request):
    obj2=UserRegister.objects.all()
    context={
        'product':obj2
    }

    return render(request,'admin/add_invoice.html',context)







# def add_invoice(request):
#     if request.method == 'POST':
#         # Create a form instance for the bill and populate it with data from the request
#         bill_form = BillForm(request.POST)
#         # Create a formset instance for the bill items and populate it with data from the request
#         bill_item_formset = BillItemFormSet(request.POST)

#         if bill_form.is_valid() and bill_item_formset.is_valid():
#             # Save the bill form to get the bill instance
#             bill = bill_form.save()
#             # Save each form in the formset to create bill items associated with the bill
#             for form in bill_item_formset:
#                 if form.cleaned_data:
#                     bill_item = form.save(commit=False)
#                     bill_item.bill = bill
#                     bill_item.save()

#             return redirect('invoice_detail', bill_id=bill.id)

#     else:
#         # Create a blank form instance for the bill
#         bill_form = BillForm()
#         # Create a blank formset instance for the bill items
#         bill_item_formset = BillItemFormSet()

#     return render(request, 'admin/add_invoice.html', {'bill_form': bill_form, 'bill_item_formset': bill_item_formset})


from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Bill, BillItem
import json


# def add_invoice(request):
#     if request.method == 'POST':
#         # Extract data from the form
#         bill_number = request.POST['bill_number']
#         date = request.POST['date']
#         customer_name = request.POST['customer_name']
#         item_type = request.POST['item_type']
#         amount = request.POST['amount']
#         description = request.POST['description']

#         # Create or get the customer object
#         customer, _ = UserRegister.objects.get_or_create(name=customer_name)

#         # Create a new bill
#         bill = Bill.objects.create(bill_number=bill_number, date=date, customer=customer)

#         # Create a new bill item
#         BillItem.objects.create(bill=bill, item_type=item_type, amount=amount)

#         # Update the total amount for the bill
#         total_amount = BillItem.objects.filter(bill=bill).aggregate(Sum('amount'))['amount__sum']
#         bill.total_amount = total_amount
#         bill.save()

#         return HttpResponse('<script>alert("Bill Generated");window.location.href="/add_invoice"</script>')

#     else:
#       return render(request,'admin/add_invoice.html')


def view_doctors(request):
    obj2=DoctorRegister.objects.all()
    context={
        'product':obj2
    }

    return render(request,'admin/view_doctors.html',context)





def view_complaints(request):
    obj=ComplaintBox.objects.all()
    context={
        'order':obj
        }


    return render(request,'admin/view_complaints.html',context)



def delete_doctor(request):
    id = request.GET.get("id")
    
    # Retrieve doctor's information based on the provided ID
    doctor = DoctorRegister.objects.filter(doc_id=id).first()
    
    if doctor:
        # Delete the doctor's entry from the DoctorRegister table
        doctor.delete()
        
        # Find the corresponding entry in the LoginModule table using the doctor's email
        login_entry = LoginModule.objects.filter(l_email=doctor.doctor_email).first()
        
        if login_entry:
            # Delete the doctor's entry from the LoginModule table
            login_entry.delete()
            
            # Redirect to the view_doctors page after successful deletion
            return HttpResponse('<script>alert("Doctor deleted");window.location.href="/view_doctors"</script>')
    
    # If the doctor's information is not found or deletion fails, redirect to view_doctors page with an alert
    return HttpResponse('<script>alert("Doctor deletion failed");window.location.href="/view_doctors"</script>')


def delete_products(request):
  
    id=request.GET["id"]
    branch=MedicalSupplies.objects.filter(mid=id).delete()
           
    return HttpResponse('<script>alert("Product Deleted");window.location.href="/view_products"</script>')



def edit_doctor(request):
    id=request.GET["id"]
    print(id)
    obj2=DoctorRegister.objects.filter(doc_id=id)
    context={
        'list':obj2
    }
    if request.POST:
        name = request.POST['doctor_name']
        email = request.POST['doctor_email']
        phone = request.POST['doctor_phone']
        address = request.POST['doctor_address']
        start_hour = request.POST['start_hour']
        end_hour = request.POST['end_hour']
        doctor_availability = request.POST['doctor_availability']
        doctor_specializations = request.POST['doctor_specializations']
        doctor_password = request.POST['doctor_password']
       
        aot=DoctorRegister.objects.filter(doc_id=id).update(doctor_name=name,
                                                  doctor_email=email,
                                                  doctor_phone=phone,
                                                  doctor_address=address,
                                                  start_hour=start_hour,
                                                  end_hour=end_hour,
                                                  doctor_availability=doctor_availability,
                                                  doctor_specializations=doctor_specializations,
                                                  doctor_password=doctor_password,
                                                #   doc_pass=doc_pass,
                                                  u5="approved",
                                                 )
        # aot.save()
        # aot1=LoginModule.objects.filter(doc_id=id).update(l_email=email,l_pass=doctor_password,l_type="Doctor",l_status="approved")
        # aot1.save()
        return HttpResponse('<script>alert("Updated");window.location.href="/view_doctors"</script>')


    return render(request,'admin/edit_doctor.html',context)






def admin_home(request):

    return render(request,'admin/admin_home.html')
from datetime import datetime, time, timedelta

def get_available_slots(request):
    if request.method == 'GET':
        doctor_id = request.GET.get('doctor_id')
        date_str = request.GET.get('date')

        # Parse the string date into a datetime.date object
        date = datetime.strptime(date_str, '%Y-%m-%d').date()

        # Retrieve existing appointments for the selected doctor on the chosen date
        existing_appointments = Appointment.objects.filter(
            doctor_id=doctor_id,
            date=date
        )

        # Retrieve the doctor's working hours
        doctor = DoctorRegister.objects.get(doc_id=doctor_id)
        start_time = datetime.combine(date, doctor.start_time)
        end_time = datetime.combine(date, doctor.end_time)

        # Generate available time slots
        available_slots = []
        current_time = start_time
        while current_time < end_time:
            slot_end_time = (current_time + timedelta(minutes=30)).strftime('%H:%M')
            # Check if the current slot overlaps with any existing appointments
            if not existing_appointments.filter(start_time__lte=current_time.time(), end_time__gte=slot_end_time).exists():
                available_slots.append({'start_time': current_time.time().strftime('%H:%M'), 'end_time': slot_end_time})
            current_time += timedelta(minutes=30)

        return JsonResponse(available_slots, safe=False)

    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)


from datetime import datetime

def book_appointment(request):
    if request.method == 'POST':
        name = request.POST.get('u_name')
        email = request.POST.get('u_email')
        phone = request.POST.get('u_phone')
        date = request.POST.get('u_date')
        message = request.POST.get('u_message')
        specialization = request.POST.get('specialization')
        doctor_id = request.POST.get('doctor')
        previous_history = request.FILES['previous_history']

        # Retrieve the selected doctor object
        doctor = DoctorRegister.objects.get(doc_id=doctor_id)

        # Convert start and end times of the selected doctor to strings
        start_time_str = doctor.start_time.strftime('%H:%M')
        end_time_str = doctor.end_time.strftime('%H:%M')

        # Retrieve existing appointments for the selected doctor on the chosen date
        existing_appointments = Appointment.objects.filter(
            doctor=doctor,
            date=date
        )

        # Parse user-selected start and end times
        user_start_time = datetime.strptime(request.POST.get('start_hour'), '%H:%M').time()
        user_end_time = datetime.strptime(request.POST.get('end_hour'), '%H:%M').time()

        # Check if there are any existing appointments within the chosen time slot
        overlapping_appointments = existing_appointments.filter(
            start_time__lt=user_end_time,
            end_time__gt=user_start_time
        )

        if overlapping_appointments.exists():
            # Inform the user that the slot is already booked
            return HttpResponse('<script>alert("This slot is already booked. Please choose a different time.");window.location.href="/book_appoitment"</script>')

        # Check if the chosen time slot falls within the doctor's working hours
        if not (doctor.start_time <= user_start_time < user_end_time <= doctor.end_time):
            # Inform the user that the chosen time is outside the doctor's working hours
            return HttpResponse('<script>alert("Please book within the working hours of the doctor.");window.location.href="/book_appoitment"</script>')

        # Create the appointment object
        appointment = Appointment.objects.create(
            name=name,
            email=email,
            phone=phone,
            date=date,
            message=message,
            specialization=specialization,
            doctor=doctor,
            start_time=user_start_time,
            end_time=user_end_time,
            previous_history=previous_history
        )

        # Save the appointment
        appointment.save()

        return HttpResponse('<script>alert("Booked");window.location.href="/book_appoitment"</script>')

    elif request.method == 'GET':
        # Handle GET request
        # Render the appointment booking form
        doctors = DoctorRegister.objects.all()
        unique_specializations = set(doctor.doctor_specializations for doctor in doctors)
        context = {
            'unique_specializations': unique_specializations,
            'doctors': doctors,
        }
        return render(request, 'user/book_appoitment.html', context)

    else:
        # Handle other HTTP methods
        return HttpResponse('Method not allowed.', status=405)


def user_home(request):

    return render(request,'user/user_home.html')

def edit_products(request):
    id=request.GET["id"]
    print(id)
    bott=MedicalSupplies.objects.filter(mid=id)
    context={
        'bottt':bott
    }
    if request.POST:
        id=request.GET["id"]
        print(id)
        bot=MedicalSupplies.objects.get(mid=id)
        
        m_name = request.POST['item_name']
        m_quantity = request.POST['item_quantity']
        m_brand = request.POST['item_brand']
        m_model = request.POST['item_model']
        m_type = request.POST['item_type']
        m_description = request.POST['item_description']
        # m_image = request.FILES['item_image']
        aot=MedicalSupplies.objects.filter(mid=id).update(m_name=m_name,
                                                  m_quantity=m_quantity,
                                                  m_brand=m_brand,
                                                  m_model=m_model,
                                                  m_type=m_type,
                                                  m_description=m_description,
                                                #   m_image=m_image,
                                               
                                            
                                                 )
        # aot.save()
       
        return HttpResponse('<script>alert("Product Updated");window.location.href="/view_products"</script>')



    return render(request,'admin/edit_products.html',context)

def add_products(request):
    if request.POST:
        m_name = request.POST['item_name']
        m_quantity = request.POST['item_quantity']
        m_brand = request.POST['item_brand']
        m_model = request.POST['item_model']
        m_type = request.POST['item_type']
        m_description = request.POST['item_description']
        m_image = request.FILES['item_image']
        aot=MedicalSupplies.objects.create(m_name=m_name,
                                                  m_quantity=m_quantity,
                                                  m_brand=m_brand,
                                                  m_model=m_model,
                                                  m_type=m_type,
                                                  m_description=m_description,
                                                  m_image=m_image,
                                               
                                            
                                                 )
        aot.save()
       
        return HttpResponse('<script>alert("Product Added");window.location.href="/add_products"</script>')



    return render(request,'admin/add_products.html')

def view_products(request):
    categories = MedicalSupplies.objects.values('m_type').distinct()
    supplies = MedicalSupplies.objects.all()

    context = {
        'categories': categories,
        'obj': supplies,
    }
    return render(request, 'admin/view_products.html', context)


def doctor_home(request):

    return render(request,'doctor/doctor_home.html')


def view_appoitment(request):
    doc_id=request.session.get("doc_id")
    print(doc_id)

    doc = Appointment.objects.filter(doctor=doc_id)
    context={
        'appointment':doc
    }


    return render(request,'doctor/view_appoitment.html',context)


def timeline(request):
    doctors = DoctorRegister.objects.all()
    context={
        'doctor':doctors,
    }
    

    return render(request,'user/timeline.html',context)





def add_doctors(request):
    
    if request.POST:
        name = request.POST['doctor_name']
        email = request.POST['doctor_email']
        phone = request.POST['doctor_phone']
        address = request.POST['doctor_address']
        start_hour = request.POST['start_hour']
        end_hour = request.POST['end_hour']
        doctor_availability = request.POST['doctor_availability']
        doctor_specializations = request.POST['doctor_specializations']
        doctor_password = request.POST['doctor_password']
        if(LoginModule.objects.filter(l_email=email).exists()):
                return HttpResponse('<script>alert("Email already exits");window.location.href="/register_doctors"</script>')
        else:
                aot=DoctorRegister.objects.create(doctor_name=name,
                                                  doctor_email=email,
                                                  doctor_phone=phone,
                                                  doctor_address=address,
                                                  start_time=start_hour,
                                                  end_time=end_hour,
                                                  doctor_availability=doctor_availability,
                                                  doctor_specializations=doctor_specializations,
                                                  doctor_password=doctor_password,
                                                #   doc_pass=doc_pass,
                                                  u5="approved",
                                                 )
                aot.save()
                aot1=LoginModule.objects.create(l_email=email,l_pass=doctor_password,l_type="Doctor",l_status="approved")
                aot1.save()
                return HttpResponse('<script>alert("Registered");window.location.href="/add_doctors"</script>')




    return render(request,'admin/add_doctors.html')


def user_register(request):
    if request.POST:
        firstname=request.POST["user_firstname"]
        dob=request.POST["user_date"]
        email=request.POST["user_email"]
        phone=request.POST["user_phone"]
        address=request.POST["user_address"]
        u_pass=request.POST["user_password"]
        uc_pass=request.POST["user_confirm_password"]
        previous_medical_history=request.FILES["previous_medical_history"]
        
        if u_pass==uc_pass:
            if(LoginModule.objects.filter(l_email=email).exists()):
                return HttpResponse('<script>alert("Email already exits");window.location.href="/register"</script>')
            else:
                aot=UserRegister.objects.create(u_fullname=firstname,
                                                u_dob=dob,
                                                u_email=email,
                                                u_phone=phone,
                                                u_address=address,
                                                u_pass=u_pass,
                                                medical_pdf=previous_medical_history,
                                                u1="approved")
                aot.save()
                aot1=LoginModule.objects.create(l_email=email,l_pass=u_pass,l_type="user",l_status="approved")
                aot1.save()
                return HttpResponse('<script>alert("Registered");window.location.href="/login"</script>')
        else:
            return HttpResponse('<script>alert("Password Mismatch ");window.location.href="/register_user"</script>')

    return render(request,'user/user_register.html')


def loginmodule(request):
    if request.POST:
        log_user=request.POST["log_email"]
        log_pass=request.POST["log_password"]
        request.session["lol"]=log_user
        aot=LoginModule.objects.filter(Q(l_email=log_user)&Q(l_pass=log_pass))
        if aot:
            if(aot[0].l_type=="user"):
                if(aot[0].l_status=="approved"):
                    aot1=UserRegister.objects.filter(u_email=log_user)
                    request.session["uid"]=aot1[0].uid
                    return HttpResponse('<script>alert("Logged in as user");window.location.href="/user_home"</script>')
        
            elif(aot[0].l_type=="Doctor"):
                if(aot[0].l_status=="approved"):
                    aot1=DoctorRegister.objects.filter(doctor_email=log_user)
                    request.session["doc_id"]=aot1[0].doc_id
                    return HttpResponse('<script>alert("Loggedin as Doctor");window.location.href="/doctor_home"</script>')
                else:
                   return HttpResponse('<script>alert("Please Wait For Approval");window.location.href="/login"</script>')
           
            # elif(aot[0].l_type=="Lab"):
            #     if(aot[0].l_status=="approved"):
            #         aot1=LabTechnician.objects.filter(lab_email=log_user)
            #         request.session["lab_id"]=aot1[0].lab_id
            #         return HttpResponse('<script>alert("Loggedin as Labtechnician");window.location.href="/labtech_home"</script>')
            #     else:
            #        return HttpResponse('<script>alert("Please Wait For Approval");window.location.href="/login"</script>')
           
            elif(aot[0].l_type=="admin"):  
                    aot=LoginModule.objects.filter(Q(l_email=log_user)&Q(l_pass=log_pass))  
                    return HttpResponse('<script>alert("Logged in as admin");window.location.href="/admin_home"</script>')                          
        else:
                return HttpResponse('<script>alert("Invalid Username and Password");window.location.href="/login"</script>')
        

    return render(request,'login.html')
