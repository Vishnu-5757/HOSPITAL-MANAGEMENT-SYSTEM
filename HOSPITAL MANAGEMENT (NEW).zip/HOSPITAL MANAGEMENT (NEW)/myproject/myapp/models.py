from django.db import models

# Create your models here.

class UserRegister(models.Model):
    uid=models.AutoField(primary_key=True)
    u_fullname=models.CharField(max_length=100)
    u_email=models.CharField(max_length=100)
    u_phone=models.CharField(max_length=100)
    u_dob=models.CharField(max_length=100)
    u_address=models.CharField(max_length=100)
    u_pass=models.CharField(max_length=100)
    u_status=models.CharField(max_length=100)
    u1=models.CharField(max_length=100,default="")
    u2=models.CharField(max_length=100,default="")
    u3=models.CharField(max_length=100,default="")
    u4=models.CharField(max_length=100,default="")
    profile_img=models.FileField(max_length=100,default="img.jpeg") 
    medical_pdf=models.FileField(max_length=100,default="img.jpeg") 


class DoctorRegister(models.Model):
    doc_id=models.AutoField(primary_key=True)
    doctor_name=models.CharField(max_length=100)
    # doc_fullname=models.CharField(max_length=100)
    doctor_email=models.CharField(max_length=100)
    doctor_phone=models.CharField(max_length=100)
    doctor_address=models.CharField(max_length=100)
    start_time = models.TimeField(null=True)
    end_time = models.TimeField(null=True)
    doctor_availability=models.CharField(max_length=100)
    doctor_specializations=models.CharField(max_length=100)
    doctor_password=models.CharField(max_length=100)
    
    doc_image=models.FileField(max_length=100,default="img.jpeg")
    # doc_pass=models.CharField(max_length=100)
    u5=models.CharField(max_length=100,default="")
    u6=models.CharField(max_length=100,default="")      
    u7=models.CharField(max_length=100,default="")    



class LoginModule(models.Model):
    l_id=models.AutoField(primary_key=True)
    l_email=models.CharField(max_length=100) 
    l_pass=models.CharField(max_length=100) 
    l_type=models.CharField(max_length=100) 
    l_status=models.CharField(max_length=100)         

class Appointment(models.Model):
    appointment_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=12)
    date = models.DateField()
    start_time = models.TimeField(null=True)
    end_time = models.TimeField(null=True)
    message = models.CharField(max_length=100)
    specialization = models.CharField(max_length=100)
    doctor = models.ForeignKey(DoctorRegister, on_delete=models.CASCADE, blank=True, null=True)
    u8 = models.CharField(max_length=100, default="")
    u9 = models.CharField(max_length=100, default="")
    u10 = models.CharField(max_length=100, default="")
    previous_history = models.FileField(max_length=100, default="img.jpeg")

class MedicalSupplies(models.Model):
    mid = models.AutoField(primary_key=True)
    m_name = models.CharField(max_length=100)
    m_quantity = models.CharField(max_length=100)
    m_brand = models.CharField(max_length=100)
    m_model = models.CharField(max_length=100)
    m_type = models.CharField(max_length=100)
    m_description = models.CharField(max_length=100)
    m_image = models.FileField(max_length=100, default="img.jpeg")
    u11 = models.CharField(max_length=100, default="pending")
    u12 = models.CharField(max_length=100, default="pending")




class ComplaintBox(models.Model):
    comp_id=models.AutoField(primary_key=True)
    comp_name=models.CharField(max_length=100)
    comp_email=models.CharField(max_length=100)
    complaint=models.CharField(max_length=100)
    comp_video=models.FileField()
    comp_status=models.CharField(max_length=100)
    u13=models.CharField(max_length=100,default="")
    u14=models.CharField(max_length=100,default="")
    uid=models.ForeignKey(UserRegister,on_delete=models.CASCADE,blank=True,null=True)    



class RegisterTest(models.Model):
    test_id=models.AutoField(primary_key=True)
    test_fullname=models.CharField(max_length=100)
    test_email=models.CharField(max_length=100)
    test_phone=models.CharField(max_length=100)
    test_choose=models.CharField(max_length=100)
    test_district=models.CharField(max_length=100)
    test_address=models.CharField(max_length=100)
    test_status=models.CharField(max_length=100)
    u15=models.CharField(max_length=100,default="")
    u16=models.CharField(max_length=100,default="")

    uid=models.ForeignKey(UserRegister,on_delete=models.CASCADE,blank=True,null=True)    


    
class Result(models.Model):
    result_id=models.AutoField(primary_key=True)
    result=models.CharField(max_length=100)
    u33=models.CharField(max_length=100,default="pending")
    u34=models.CharField(max_length=100,default="pending")
    u45=models.CharField(max_length=100,default="pending")


    patient_fullname=models.CharField(max_length=100,default="pending")
    patient_phone=models.CharField(max_length=100,default="pending")
    patient_TestType=models.CharField(max_length=100,default="pending")
    patient_date=models.DateField()
    result_status=models.CharField(max_length=100,default="pending")
    result_description=models.CharField(max_length=100,default="pending")
    test_id=models.ForeignKey(RegisterTest,on_delete=models.CASCADE,blank=True,null=True)

class Bill(models.Model):
    bill_number = models.CharField(max_length=100,default="pending") 
    date = models.DateField(null=True, blank=True)  
    customer = models.ForeignKey(UserRegister, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"Bill for {self.customer.name}"

class BillItem(models.Model):
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE)
    item_type = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(max_length=100,default="pending")

    def __str__(self):
        return f"{self.item_type} - {self.amount}"