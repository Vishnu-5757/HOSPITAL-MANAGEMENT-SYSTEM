from django.contrib import admin
from . models import *

# Register your models here.

admin.site.register(LoginModule)
admin.site.register(UserRegister)
admin.site.register(DoctorRegister)
admin.site.register(Appointment)
admin.site.register(Result)
