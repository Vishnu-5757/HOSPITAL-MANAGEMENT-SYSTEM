"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('login/', views.loginmodule),
    path('register_user', views.user_register),
    path('user_home', views.user_home),
    path('admin_home', views.admin_home),
    path('add_doctors', views.add_doctors),
    path('view_doctors', views.view_doctors),
    path('edit_doctor', views.edit_doctor),
    path('delete_doctor', views.delete_doctor),
    path('book_appoitment', views.book_appointment),
    path('timeline', views.timeline),
    path('get_available_slots', views.get_available_slots, name='get_available_slots'),
    path('doctor_home', views.doctor_home, name='doctor_home'),
    path('view_appoitment', views.view_appoitment, name='view_appoitment'),
    path('add_products', views.add_products, name='add_products'),
    path('view_products', views.view_products, name='view_products'),
    path('edit_products', views.edit_products, name='edit_products'),
    path('delete_products', views.delete_products, name='delete_products'),
    path('complatint', views.complatint, name='complatint'),
    path('view_complaints', views.view_complaints, name='view_complaints'),
    path('test', views.test, name='test'),
    path('view_tests', views.view_tests, name='view_tests'),
    path('make_report', views.make_report, name='make_report'),
    path('view_result', views.view_result, name='view_result'),
    path('add_invoice', views.add_invoice, name='add_invoice'),
    path('make_bill', views.make_bill, name='make_bill'),
    # path('submit_bill/',views.submit_bill, name='submit_bill'),
    
]
